package com.lifewriter.application;

public abstract class decoding {

  public static void main(String[] args) {

  }

}
