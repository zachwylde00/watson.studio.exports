package com.lifewriter.application;

public abstract class pathcreatorservice {

  public static void main(String[] args) {

  }

}
