package com.lifewriter.application;

public abstract class nonvirtualprinting {

  public static void main(String[] args) {

  }

}
