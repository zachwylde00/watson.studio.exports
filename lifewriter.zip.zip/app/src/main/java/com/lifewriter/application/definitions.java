package com.lifewriter.application;

public abstract class definitions {

  public static void main(String[] args) {

  

}
