package com.lifewriter.application.fileworkerservice;

abstract class editorservice {

  public static void main(String[] args) {

  

}
