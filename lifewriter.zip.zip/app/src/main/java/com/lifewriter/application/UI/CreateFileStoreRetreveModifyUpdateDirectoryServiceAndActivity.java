package com.lifewriter.application.UI;

public abstract class CreateFileStoreRetreveModifyUpdateDirectoryServiceAndActivity {

  public static void main(String[] args) {

  }

}
