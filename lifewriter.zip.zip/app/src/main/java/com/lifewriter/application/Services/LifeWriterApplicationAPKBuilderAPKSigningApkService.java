//package com.lifewriter.application.Services;

//public abstract LifeWriterApplicationAPKBuilderAPKSigningApkService,;

 // public static void main String() args;



//activate services showstatuses
//onstart(use service to build and create apk)