package com.lifewriter.application.UI.Services;

//public abstract  UIService {

  //public static@ main(String[] args);



