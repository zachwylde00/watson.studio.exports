package com.lifewriter.application.URI;

//public abstract interface MiningAndTransactionConfirmationService {

 // public static void main(String[] args);


