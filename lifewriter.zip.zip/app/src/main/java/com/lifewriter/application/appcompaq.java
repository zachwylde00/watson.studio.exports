package com.lifewriter.application;

public class appcompaq {

  public static void main(String[] args) {

  }

}
