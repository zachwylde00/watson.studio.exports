package com.lifewriter.application;

public abstract interface nonvirtualclassifierjavaservice {

  public static void main(String[] args);


}
