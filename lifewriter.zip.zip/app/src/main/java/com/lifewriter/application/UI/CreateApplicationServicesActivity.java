package com.lifewriter.application.UI;

public abstract class CreateApplicationServicesActivity {

  public static void main(String[] args) {

  }

}
