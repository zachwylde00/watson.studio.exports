package com.lifewriter.application;

public abstract interface nonvirtualgenesisblocktoatomicnanostructercinversionservice {

 // public static void main(String[] args);


}
