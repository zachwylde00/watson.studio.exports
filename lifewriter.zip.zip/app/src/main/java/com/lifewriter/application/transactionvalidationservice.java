package com.lifewriter.application;

public abstract enum transactionvalidationservice {

  public static void main(String[] args) {

  }

}
