package com.lifewriter.application;

public abstract class nullobjectoverrideservice {

  public static void main(String[] args) {

  }

}
