package com.lifewriter.application;

public abstract class nonvirtualdirectorclassifierservice {

  public static void main(String[] args) {

  }

}
