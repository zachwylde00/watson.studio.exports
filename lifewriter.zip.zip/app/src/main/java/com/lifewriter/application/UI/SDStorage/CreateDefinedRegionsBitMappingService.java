package com.lifewriter.application.UI.SDStorage;

public interface CreateDefinedRegionsBitMappingService {

  public static void main(String[] args);


}
