package com.lifewriter.application;

 interface deviceUIsettingsservice {

  public static void main(String[] args);



