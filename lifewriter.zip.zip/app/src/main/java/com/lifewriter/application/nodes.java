package com.lifewriter.application;

public abstract class nodes {

  public static void main(String[] args) {

  }

}
