package com.lifewriter.application;

interface DeviceRootService {

  public static void main(String[] args);



