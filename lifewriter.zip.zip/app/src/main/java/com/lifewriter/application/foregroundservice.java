package com.lifewriter.application;

//public abstract enum foregroundservice {

 // public static void main(String[] args); 

  {

 }
