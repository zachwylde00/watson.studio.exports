package com.lifewriter.application;

public abstract interface javaunknowndataclassifierservice {

  public static void main(String[] args);


}
