package com.lifewriter.application;

abstract class fileworkerservices {

  public static void main(String[] args) {

  }

}
