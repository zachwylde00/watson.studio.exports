package com.lifewriter.application;

//public abstract enum nonvirtualdirectorypathwaysconfigurationservice {

  //public static void main(String[] args) {

  

 }
