package com.lifewriter.application;

public abstract class identifierservice {

  public static void main(String[] args) {

  }

}
