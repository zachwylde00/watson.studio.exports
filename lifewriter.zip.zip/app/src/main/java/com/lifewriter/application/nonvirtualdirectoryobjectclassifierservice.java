package com.lifewriter.application;

public abstract interface nonvirtualdirectoryobjectclassifierservice {

  public static void main(String[] args);


}
