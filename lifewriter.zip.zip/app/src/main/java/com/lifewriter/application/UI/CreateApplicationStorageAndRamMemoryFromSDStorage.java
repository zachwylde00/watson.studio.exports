package com.lifewriter.application.UI;

public class CreateApplicationStorageAndRamMemoryFromSDStorage {

  public static void main(String[] args) {

  }

}
