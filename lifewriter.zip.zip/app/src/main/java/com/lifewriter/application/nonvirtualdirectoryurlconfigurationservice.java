package com.lifewriter.application;

public abstract enum nonvirtualdirectoryurlconfigurationservice {

  public static void main(String[] args) {

  }

}
