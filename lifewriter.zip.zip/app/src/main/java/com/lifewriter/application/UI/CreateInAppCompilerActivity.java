package com.lifewriter.application.UI;

public abstract class CreateInAppCompilerActivity {

  public static void main(String[] args) {

  }

}
