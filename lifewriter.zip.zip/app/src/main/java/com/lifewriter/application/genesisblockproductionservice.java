package com.lifewriter.application;

abstract interface genesisblockproductionservice {

  public static void main(String[] args);


}
