package com.lifewriter.application.UI;

public abstract class CreateApplicationFileEditorService {

  public static void main(String[] args) {

  }

}
