package com.lifewriter.application.UI.Directory.ArtificialIntelligence;

public interface CreateApplicationServicesActivities {

  public static void main(String[] args);


}
