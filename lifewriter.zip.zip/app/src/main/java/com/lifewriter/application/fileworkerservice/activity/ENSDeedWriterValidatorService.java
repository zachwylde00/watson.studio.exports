package com.lifewriter.application.fileworkerservice.activity;

public abstract class ENSDeedWriterValidatorService {

  public static void main(String[] args) {

  }

}
// activTe service show statuses
//onstart(show statuses onscreen view)