package com.lifewriter.application.UI;

public abstract interface DeviceUnlockBootloaderService {

  //public static@ main(String[] args);


}
