package com.lifewriter.application;

public abstract class autoeditorservice {

  public static void main(String[] args) {

  }

}
