package com.lifewriter.application.UI;

public abstract class CreateApplicationUIDirectory {

  public static void main(String[] args) {

  }

}
