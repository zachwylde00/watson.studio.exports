package com.lifewriter.application;

public abstract class CreateApplicationDirectory {

  public static void main(String[] args) {

  }

}
