package com.lifewriter.application;

abstract class fileworkerui {

  public static void main(String[] args) {

  }

}
