package com.lifewriter.application;

public abstract interface nonvirtualobjectprintservice {

  public static void main(String[] args);


}
