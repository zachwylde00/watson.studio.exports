package com.lifewriter.application.Directory.UI;

public abstract class CreateApplicationFunctionAutoCorrectionService {

  public static void main(String[] args) {

  }

}
