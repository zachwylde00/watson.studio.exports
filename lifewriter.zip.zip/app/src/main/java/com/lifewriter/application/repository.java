package com.lifewriter.application;

public final class repository {

  public static void main(String[] args) {

  }

}
