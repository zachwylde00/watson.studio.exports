package com.lifewriter.application.UI.ApplicationUI.Services;

public abstract interface SuperUserHelperService {

  //public static void main(String[] args);


}
