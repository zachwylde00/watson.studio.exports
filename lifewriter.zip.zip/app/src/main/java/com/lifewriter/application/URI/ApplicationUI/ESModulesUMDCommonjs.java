package com.lifewriter.application.URI.ApplicationUI;

//public abstract  ESModulesUMDCommonjs {

 // public abstract main String() args,;


//script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.1.1/gsap.min.js"></script>
//import { gsap } from "gsap";
//import { gsap } from "gsap";
//import { PixiPlugin } from "gsap/PixiPlugin.js";
//import { MotionPathPlugin } from "gsap/MotionPathPlugin.js";

//without this line, PixiPlugin and MotionPathPlugin may get dropped by your bundler (tree shaking)...
//gsap.registerPlugin(PixiPlugin, MotionPathPlugin);
// to get the UMD versions, notice the "/dist/" in the path...

// some older systems may need something like this_var gsap = require("gsap/dist/gsap").gsap;
//var MotionPathPlugin = require("gsap/dist/MotionPathPlugin").MotionPathPlugin;

// using destructuring assignment
//const { gsap } = require("gsap/dist/gsap");
//const { MotionPathPlugin } = require("gsap/dist/MotionPathPlugin");

// using import syntax
//import { gsap } from "gsap/dist/gsap";
//import { MotionPathPlugin } from "gsap/dist/MotionPathPlugin";