package com.lifewriter.application;

public final class resources {

  public static void main(String[] args) {

  }

}
