package com.lifewriter.application;

public abstract interface nonvirtualatomictogenesiblockmassdensityratioservice {

  public static void main(String[] args);


}
