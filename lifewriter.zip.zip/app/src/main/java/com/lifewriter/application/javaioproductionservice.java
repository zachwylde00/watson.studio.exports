package com.lifewriter.application;

public abstract enum javaioproductionservice {

  public static void main(String[] args) {

  }

}
