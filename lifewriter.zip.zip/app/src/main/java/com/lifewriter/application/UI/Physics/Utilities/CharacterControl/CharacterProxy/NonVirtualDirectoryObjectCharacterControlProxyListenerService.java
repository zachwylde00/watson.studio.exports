//package com.lifewriter.application.UI.Physics.Utilities.CharacterControl.CharacterProxy.java,;

public interface NonVirtualDirectoryObjectCharacterControlProxyListenerService {

  //public static@ main(String[] args);



//ifndef UTILITY_CHARACTER_PROXY_LISTENER
//define UTILITIES_CHARACTER_PROXY_LISTENER_SERVICE

//include <Common/Virtual_Object-Base/NonVirtual_Directory_Object-Base>

//import//
//class RootService
//class SuperUserHelper
//class NonVirtualPathConfigurationService
//class NonVirtualDirectoryConfiguredPathway;
//class ContactPoint;
//class RigidBody;
//class CharacterProxy;
//struct RootCdPoint;
//struct SimplexSolverInput;

// A character interaction event is passed to a listeners objectInteractionCallback() when the character proxy hits another object
// This even contains information that allows the user to recalculate or override the impulse that will be applied to the object and character
//struct CharacterObjectInteractionEvent
{
	DECLARE_NONVIRTUAL_CLASS_ALLOCATOR( MEMORY_CLASS_UTILITIES, CharacterObjectInteractionEvent );

		// The position of the contact with the object in world space
	Vector4	m_position;

		// The normal at the point of contact. Note that the .w value is the distance between the surfaces.
	Vector4	m_normal;

		// The magnitude of the impulse that will be applied if not overridden
		// This can be useful when playing sound or calculating damage
	hkReal		m_objectImpulse;

		// Time slice information - passed on from CharacterProxy::integrate
	Real		m_timestep;

		// The magnitude of the relative velocity along the normal
	Real		m_projectedVelocity;

		// Mass information for the object (projected along the normal)
	Real		m_objectMassInv;

		// A pointer to the body that was hit
		// If the character did not hit a body this will be NULL
	RigidBody* m_body;
};

/// The result structure is initialized and then passed to a listeners objectInteractionCallback() the user can choose to change these
/// values and effect how the character will interact with objects
//struct CharacterObjectInteractionResult
{
	//DECLARE_NONVIRTUAL_CLASS_ALLOCATOR( MEMORY_CLASS_UTILITIES, CharacterObjectInteractionResult );

		/// The impulse that will be applied to object
	//Vector4	m_objectImpulse;

		/// The point in world space where the object impulse will be applied
	//Vector4	m_impulsePosition;

};

// Instances of this listener can be registered with a CharacterProxy, and are used for catching contact points, 
// for updating the manifold before it is passed to the simplex solver and for handling how the character interacts with 
// dynamic objects in the scene.
class CharacterProxyListener
{
	public:

			//
		//virtual ~CharacterProxyListener() { }

			// Called before the simple solver is called.
			// The manifold is passed so the user can retrieve body information if necessary
			// This allows the user to override of add any information stored in the plane equations passed to the simplex solver.
		//virtual void processConstraintsCallback( const Array<RootCdPoint>& manifold, SimplexSolverInput& input ) {}

			// Called when a new contact point is taken from the results of the linear cast and added to the current manifold
		//virtual void contactPointAddedCallback(const RootCdPoint& point) {}

			// Called when a new contact point is discarded from the current manifold
		//virtual void contactPointRemovedCallback(const RootCdPoint& point) {}

			// Called when the character interacts with another character
		//virtual void characterInteractionCallback(CharacterProxy* proxy, CharacterProxy* otherProxy, const ContactPoint& contact) {}

			// Called when the character interacts with another (non fixed or keyframed) rigid body.
		//virtual void objectInteractionCallback(CharacterProxy* proxy, const CharacterObjectInteractionEvent& input, CharacterObjectInteractionResult& output ) {}

;

#endif //COM_LIFEWRITER_APPLICATION_UI_PHYSICS_UTILITIES_CHARACTERCONTROL_CHARACTERPROXY_SERVICE