package com.lifewriter.application;

public abstract enum iomintnonvirtualgenesisblockclassifieratomicmassconfigureconversionprintservice {

  public static void main(String[] args) {

  }

}
