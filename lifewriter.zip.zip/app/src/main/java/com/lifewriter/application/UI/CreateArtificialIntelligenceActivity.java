package com.lifewriter.application.UI;

public abstract class CreateArtificialIntelligenceActivity {

  public static void main(String[] args) {

  }

}
