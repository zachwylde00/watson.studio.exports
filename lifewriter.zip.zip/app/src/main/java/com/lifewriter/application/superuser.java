package com.lifewriter.application;

public class superuser {

  public static void main(String[] args) {

  }

}
