package com.lifewriter.application;

abstract class valueproductionservices {

  public static void main(String[] args) {

  }

}
