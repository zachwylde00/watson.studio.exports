package com.lifewriter.application;

public abstract class CreateObtainRootService {

  public static void main(String[] args) {

  }

}
