package com.lifewriter.application.UI;

public abstract interface ConfigureRootSuperUserService {

  //public static@ main(String[] args);


}
