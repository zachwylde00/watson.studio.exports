package com.lifewriter.application;

abstract class moneyproductionservice {

  public static void main(String[] args) {

  }

}
