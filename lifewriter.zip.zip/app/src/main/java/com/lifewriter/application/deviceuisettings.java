package com.lifewriter.application;

final class deviceuisettings {

  public static void main(String[] args) {

  }

}
