package com.lifewriter.application;

public class actions {

  public static void main(String[] args) {

  }

}
