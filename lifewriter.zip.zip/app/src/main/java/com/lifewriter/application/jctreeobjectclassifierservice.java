package com.lifewriter.application;

abstract class jctreeobjectclassifierservice {

  public static void main(String[] args) {

  }

}
