package com.lifewriter.application;

public abstract class errorcheckerservice {

  public static void main(String[] args) {

  }

}
