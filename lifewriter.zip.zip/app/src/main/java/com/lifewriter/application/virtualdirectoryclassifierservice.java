package com.lifewriter.application;

public abstract class virtualdirectoryclassifierservice {

  public static void main(String[] args) {

  }

}
