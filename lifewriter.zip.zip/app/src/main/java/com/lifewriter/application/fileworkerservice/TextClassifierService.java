package com.lifewriter.application.fileworkerservice;

 //interface TextClassifierService {

  //public static@ main(String[] args);



