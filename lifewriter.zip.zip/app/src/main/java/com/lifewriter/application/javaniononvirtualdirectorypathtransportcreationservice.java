package com.lifewriter.application;

public final enum javaniononvirtualdirectorypathtransportcreationservice {

  public static void main(String[] args) {

  }

}
