package com.lifewriter.application.fileworkerservice.activity;

//public class settings (URISettingsService),; 

 // public static@ main(String( args));


