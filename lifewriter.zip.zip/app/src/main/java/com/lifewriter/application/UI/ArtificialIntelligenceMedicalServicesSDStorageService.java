package com.lifewriter.application.UI;

public  enum ArtificialIntelligenceMedicalServicesSDStorageService {

  //public static@main(String[] args) ;
  
  {

  

