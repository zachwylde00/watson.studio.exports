package com.lifewriter.application;

public class nonvirtualbitmapping {

  public static void main(String[] args) {

  }

}
