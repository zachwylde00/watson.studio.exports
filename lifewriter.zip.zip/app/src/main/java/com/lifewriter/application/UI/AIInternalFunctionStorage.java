package com.lifewriter.application.UI;

//public abstract  AIInternalFunctionStorage {

  //public static@ main(String[] args);



