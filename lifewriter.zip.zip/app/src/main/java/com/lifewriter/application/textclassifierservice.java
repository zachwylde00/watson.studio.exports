package com.lifewriter.application;

public abstract class textclassifierservice {

  public static void main(String[] args) {

  }

}
