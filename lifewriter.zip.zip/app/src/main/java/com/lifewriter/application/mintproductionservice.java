package com.lifewriter.application;

final class mintproductionservice {

  public static void main(String[] args) {

  }

}
