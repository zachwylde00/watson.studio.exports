package com.lifewriter.application;

public abstract interface javaprintserviceclassifier {

  public static void main(String[] args);


}
