package com.lifewriter.application;

final class beaconservices {

  public static void main(String[] args) {

  }

}
