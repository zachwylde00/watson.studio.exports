package com.lifewriter.application.Services;

public abstract interface ApplicationAdServices {

//  public static void main(String[] args);


}
//onstart(activate all services show onscreen view (active seevuce-flipview))
//include import corrections and updated files
// include autorepair services issues using fileworkerseevice 