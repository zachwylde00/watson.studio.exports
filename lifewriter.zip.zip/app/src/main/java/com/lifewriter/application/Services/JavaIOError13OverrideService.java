//package com.lifewriter.application.Services;

// public  interface;
 //JavaIO Application OverrideError/deniedPermissionOverride activity JavaIOError13OverrideService,;

  //static@ main (String(args));


//override all java.io denied permissions
//then activate all files and all services. 
 // run file looped concurrent as formatted apk and UI services