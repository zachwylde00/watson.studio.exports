package com.lifewriter.application.UI;

public abstract class CreateNonvirtualBitMappingDirectory {

  public static void main(String[] args) {

  }

}
