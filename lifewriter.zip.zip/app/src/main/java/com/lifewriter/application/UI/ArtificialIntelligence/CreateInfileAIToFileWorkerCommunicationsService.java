package com.lifewriter.application.UI.ArtificialIntelligence;

public interface CreateInfileAIToFileWorkerCommunicationsService {

  public static void main(String[] args);


}
