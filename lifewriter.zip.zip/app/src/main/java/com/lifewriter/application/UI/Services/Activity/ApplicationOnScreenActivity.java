package com.lifewriter.application.UI.Services.Activity;

public abstract enum ApplicationOnScreenActivity {

  public static void main(String[] args) {

  }

}
