package com.lifewriter.application;

final class radioservices {

  public static void main(String[] args) {

  }

}
