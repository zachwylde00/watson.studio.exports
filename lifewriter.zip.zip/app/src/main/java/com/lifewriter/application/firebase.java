package com.lifewriter.application;

public abstract class firebase {

  public static void main(String[] args) {

  }

}
