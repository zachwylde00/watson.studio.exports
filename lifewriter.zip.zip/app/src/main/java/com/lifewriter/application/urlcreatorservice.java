package com.lifewriter.application;

public abstract class urlcreatorservice {

  public static void main(String[] args) {

  }

}
