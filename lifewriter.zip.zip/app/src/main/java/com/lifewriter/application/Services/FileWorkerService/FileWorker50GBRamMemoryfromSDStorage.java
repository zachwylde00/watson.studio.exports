package com.lifewriter.application.Services.FileWorkerService;

//public inerface RamMemoryFunction capabilities FileWorker50GBRamMemoryfromSDStorage,; 
  //public static@ main String() ;



