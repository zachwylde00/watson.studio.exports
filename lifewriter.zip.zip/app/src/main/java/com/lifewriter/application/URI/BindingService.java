package com.lifewriter.application.URI;

public abstract interface BindingService {

  //public static void main(String[] args);


}
//activate service show statuses bindingservice results