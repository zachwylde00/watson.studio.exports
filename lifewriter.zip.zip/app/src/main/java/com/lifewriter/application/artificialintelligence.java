package com.lifewriter.application;

public class artificialintelligence {

  public static void main(String[] args) {

  }

}
