package com.lifewriter.application.UI;

public abstract interface ArtificialIntelligenceRelayResponseCapabilitiesandActivityService {

  //public static void main(String[] args);


}
