package com.lifewriter.application.UI;

public abstract class CreateArtificialIntelligenceDirectory {

  public static void main(String[] args) {

  }

}
