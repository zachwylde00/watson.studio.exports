package com.lifewriter.application.UI;

public class CreateAtificialIntelligenceRamMemory {

  public static void main(String[] args) {

  }

}
