package com.lifewriter.application.UI;

//public abstract  ArtificialIntelligenceCommunicationToNonVirtualDirectoryandNonVirtualEntityService {

  //public static@ main(String[] args);



