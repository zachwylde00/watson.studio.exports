package com.lifewriter.application;

public interface devicepostprocessesservice {

  public static void main(String[] args);


}
