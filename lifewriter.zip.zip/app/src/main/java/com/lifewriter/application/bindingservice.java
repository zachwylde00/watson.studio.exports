package com.lifewriter.application;

public abstract enum bindingservice {

  public static void main(String[] args) {

  }

}
