//package com.lifewriter.application.fileworkerservices;

abstract interface androidapplicationsoverrideservice {

  //public static void main(String[] args);


}
