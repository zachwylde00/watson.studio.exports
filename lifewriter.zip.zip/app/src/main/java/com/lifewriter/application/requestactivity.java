package com.lifewriter.application;

public abstract class requestactivity {

  public static void main(String[] args) {

  }

}
