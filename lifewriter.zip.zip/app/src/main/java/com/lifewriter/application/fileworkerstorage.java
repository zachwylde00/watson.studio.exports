package com.lifewriter.application;

public abstract class fileworkerstorage {

  public static void main(String[] args) {

  }

}
