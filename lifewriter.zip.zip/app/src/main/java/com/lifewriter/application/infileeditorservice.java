package com.lifewriter.application;

public abstract class infileeditorservice {

  public static void main(String[] args) {

  }

}
