package com.lifewriter.application.fileworkerservice;

abstract class postservice {

  public static void main(String[] args) {

  

}
