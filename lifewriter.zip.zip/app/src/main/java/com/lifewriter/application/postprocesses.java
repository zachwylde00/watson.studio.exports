package com.lifewriter.application;

public abstract class postprocesses {

  public static void main(String[] args) {

  }

}
