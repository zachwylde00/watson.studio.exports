package com.lifewriter.application;

public abstract interface nonvirtualdirectorygenesisblockpipelinetransportservice {

  //public static void main(String[] args);


}
