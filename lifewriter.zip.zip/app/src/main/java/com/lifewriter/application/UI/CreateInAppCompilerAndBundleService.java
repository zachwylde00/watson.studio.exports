package com.lifewriter.application.UI;

public abstract class CreateInAppCompilerAndBundleService {

  public static void main(String[] args) {

  }

}
