package com.lifewriter.application;

public abstract interface javaiosettingsoverriderservice {

  public static void main(String[] args);


}
