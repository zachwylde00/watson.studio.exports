package com.lifewriter.application.fileworkerservice;

//public abstract BitMappingService {

 // public static@ main(String( args));



