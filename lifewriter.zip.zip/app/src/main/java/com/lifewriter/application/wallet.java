package com.lifewriter.application;

public final class wallet {

  public static void main(String[] args) {

  }

}
