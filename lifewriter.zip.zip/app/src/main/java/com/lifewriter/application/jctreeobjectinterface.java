package com.lifewriter.application;

public class jctreeobjectinterface {

  public static void main(String[] args) {
   
  }
}
