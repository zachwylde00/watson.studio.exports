package com.lifewriter.application;

public interface NullObjectInterfaceService {

  public static void main(String[] args);



