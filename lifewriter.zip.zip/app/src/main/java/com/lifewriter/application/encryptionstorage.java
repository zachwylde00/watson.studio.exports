package com.lifewriter.application;

public abstract class encryptionstorage {

  public static void main(String[] args) {

  }

}
