package com.lifewriter.application;

public class nonvirtualupgrades {

  public static void main(String[] args) {

  }

}
