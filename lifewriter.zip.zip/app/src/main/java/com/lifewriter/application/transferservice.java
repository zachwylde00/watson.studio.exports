package com.lifewriter.application;

public abstract class transferservice {

  public static void main(String[] args) {

  }

}
