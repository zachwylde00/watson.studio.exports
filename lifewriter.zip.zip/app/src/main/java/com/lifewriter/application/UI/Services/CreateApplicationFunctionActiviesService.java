package com.lifewriter.application.UI.Services;

public abstract class CreateApplicationFunctionActiviesService {

  public static void main(String[] args) {

  }

}
