package com.lifewriter.application;

final class devicesettings {

  public static void main(String[] args) {

  }

}
