package com.lifewriter.application.UI;

public abstract interface AI100gbSDStorageAsRamMemoryService {

  //public static@ main(String[] args);


}
