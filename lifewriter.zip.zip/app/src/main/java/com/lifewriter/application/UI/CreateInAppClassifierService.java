package com.lifewriter.application.UI;

public abstract class CreateInAppClassifierService {

  public static void main(String[] args) {

  }

}
