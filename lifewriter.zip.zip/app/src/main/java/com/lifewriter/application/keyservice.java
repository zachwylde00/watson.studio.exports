package com.lifewriter.application;

final class keyservice {

  public static void main(String[] args) {

  }

}
