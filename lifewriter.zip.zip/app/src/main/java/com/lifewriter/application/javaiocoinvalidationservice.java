package com.lifewriter.application;

public abstract enum javaiocoinvalidationservice {

  public static void main(String[] args) {

  }

}
