//package com.lifewriter.application.Services.FileWorkerService
//public  enum
 //WebInternetConnectionService,;

  //public static@ mainString();



