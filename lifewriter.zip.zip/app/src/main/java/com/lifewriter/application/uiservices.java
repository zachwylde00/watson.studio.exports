package com.lifewriter.application;

final class uiservices {

  public static void main(String[] args) {

  }

}
