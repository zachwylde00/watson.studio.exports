package com.lifewriter.application;

public abstract class objectprintservices {

  public static void main(String[] args) {

  }

}
