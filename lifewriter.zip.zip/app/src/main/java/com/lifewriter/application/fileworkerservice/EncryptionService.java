package com.lifewriter.application.FileWorkerService;

abstract enum EncryptionService {

  public static void main(String[] args) {

  

}
