package com.lifewriter.application;

public abstract interface javaapplicationprocessesservice {

  public static void main(String[] args);


}
