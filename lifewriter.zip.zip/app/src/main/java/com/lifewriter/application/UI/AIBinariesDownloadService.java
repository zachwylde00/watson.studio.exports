package com.lifewriter.application.UI;

public abstract interface AIBinariesDownloadService {

 // public static@ main(String[] args);


}
