package com.lifewriter.application;

public abstract interface nonvirtualobjectmodificationservice {

  public static void main(String[] args);


}
