package com.lifewriter.application;

//public interface WebsiteCallbackURL {

  //public static void main(String[] args);



//website URL:"https://unitedstatesbitcoinbankandexchange.github.io/lifewriter.application.com/"
//callback URL:"https://zachwylde00.github.io/lifewriter.application.com/postreceive/";