package com.lifewriter.application;

abstract class accelerationservices {

  public static void main(String[] args) {

  }

}
