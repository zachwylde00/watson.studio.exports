package com.lifewriter.application;

enum class genesis_block_services {

  public static void main(String[] args);
  
   {

  

