package com.lifewriter.application;

final class encryptedaddressservices {

  public static void main(String[] args) {

  }

}
