package com.lifewriter.application;

public abstract class workeractivity {

  public static void main(String[] args) {

  }

}
