package com.lifewriter.application.fileworkerservice;

//interface FileWorkerRootAccess, ;

  //public static@ main(String[] args);



