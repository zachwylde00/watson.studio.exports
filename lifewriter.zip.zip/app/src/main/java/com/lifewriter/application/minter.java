package com.lifewriter.application;

public abstract class minter {

  public static void main(String[] args) {

  }

}
