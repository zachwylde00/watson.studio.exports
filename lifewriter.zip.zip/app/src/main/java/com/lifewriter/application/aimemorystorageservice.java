package com.lifewriter.application;

final class aimemorystorageservice {

  public static void main(String[] args) {

  }

}
