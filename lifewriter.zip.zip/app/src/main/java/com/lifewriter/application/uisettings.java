package com.lifewriter.application;

public final class uisettings {

  public static void main(String[] args) {

  }

}
