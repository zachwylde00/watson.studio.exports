package com.lifewriter.application.com.APKCreator.Application.UI.ApplicationServices;

public interface Overrides {

  public static void main(String[] args);


}
