package com.lifewriter.application;

public final class nonvirtualobjectinterface {

  public static void main(String[] args) {

  }

}
