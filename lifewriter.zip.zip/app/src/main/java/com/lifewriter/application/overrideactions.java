package com.lifewriter.application;

public abstract class overrideactions {

  public static void main(String[] args) {

  }

}
