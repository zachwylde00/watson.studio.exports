package com.lifewriter.application;

final class listenerservices {

  public static void main(String[] args) {

  }

}
