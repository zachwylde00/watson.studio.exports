package com.lifewriter.application.UI.Services;

public abstract interface RootConfigurationService {

  //public static void main(String[] args);


}
