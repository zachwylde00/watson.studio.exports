package com.lifewriter.application;

public abstract enum livingorganismbitmappingservice {

  public static void main(String[] args) {

  }

}
