package com.lifewriter.application;

abstract class servicesclassifier {

  public static void main(String[] args) {

  }

}
