package com.lifewriter.application;

public abstract interface atomicmasstocellclassificationcalculationsservice {

  public static void main(String[] args);


}
