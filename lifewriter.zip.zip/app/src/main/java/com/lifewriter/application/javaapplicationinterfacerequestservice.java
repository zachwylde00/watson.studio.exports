package com.lifewriter.application;

public abstract interface javaapplicationinterfacerequestservice {

  public static void main(String[] args);


}
