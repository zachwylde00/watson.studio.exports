package com.lifewriter.application;

public abstract class miningservice {

  public static void main(String[] args) {

  }

}
