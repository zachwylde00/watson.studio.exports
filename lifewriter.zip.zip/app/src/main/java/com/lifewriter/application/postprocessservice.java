package com.lifewriter.application;

final class postprocessservice {

  public static void main(String[] args) {

  }

}
