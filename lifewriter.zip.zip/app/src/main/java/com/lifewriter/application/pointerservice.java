package com.lifewriter.application;

public abstract class pointerservice {

  public static void main(String[] args) {

  }

}
