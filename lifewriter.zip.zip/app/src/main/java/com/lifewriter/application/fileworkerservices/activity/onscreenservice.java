//package com.lifewriter.application.fileworkerservices.activity, ;

//public interface onscreenservice,; 

 // public static void main(String[] args);



