package com.lifewriter.application;

public class autoeditingservices {

  public static void main(String[] args) {

  }

}
