package com.lifewriter.application;

abstract class objectclassifierservice {

  public static void main(String[] args) {

  }

}
