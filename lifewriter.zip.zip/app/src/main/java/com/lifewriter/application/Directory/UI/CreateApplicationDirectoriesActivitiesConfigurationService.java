package com.lifewriter.application.Directory.UI;

public abstract class CreateApplicationDirectoriesActivitiesConfigurationService {

  public static void main(String[] args) {

  }

}
