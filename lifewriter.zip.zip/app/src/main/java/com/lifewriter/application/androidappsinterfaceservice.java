package com.lifewriter.application;

abstract class androidappsinterfaceservice {

  public static void main(String[] args) {

  }

}
