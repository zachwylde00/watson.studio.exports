package com.lifewriter.application;

public class encoding {

  public static void main(String[] args) {

  }

}
