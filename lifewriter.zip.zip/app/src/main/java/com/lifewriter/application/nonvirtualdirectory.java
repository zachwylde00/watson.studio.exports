package com.lifewriter.application;

public class nonvirtualdirectory {

  public static void main(String[] args) {

  }

}
