//package com.lifewriter.application;

public final interface nonvirtualobject {

  public static void main(String[] args);


}
