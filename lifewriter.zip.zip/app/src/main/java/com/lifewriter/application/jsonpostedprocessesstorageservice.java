package com.lifewriter.application;

public abstract enum jsonpostedprocessesstorageservice {

  public static void main(String[] args) {

  }

}
