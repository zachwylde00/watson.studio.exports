package com.lifewriter.application;

public class messenger {

  public static void main(String[] args) {

  }

}
