package com.lifewriter.application.UI;

public abstract interface RootFileStorageSuperUserFileStorageService {

  //public static@ main(String[] args);


}
