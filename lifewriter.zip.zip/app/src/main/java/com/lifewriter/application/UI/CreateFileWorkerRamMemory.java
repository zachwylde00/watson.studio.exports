package com.lifewriter.application.UI;

public class CreateFileWorkerRamMemory {

  public static void main(String[] args) {

  }

}
