package com.lifewriter.application;

//public UIDefined=application_interface_UI_is_artificialInelligence_and_is_application_UI ;

  public static void main(String[] args) 
  {

  

}
