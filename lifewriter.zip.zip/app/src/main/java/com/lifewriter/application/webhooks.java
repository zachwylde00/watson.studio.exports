package com.lifewriter.application;

public class webhooks {

  public static void main(String[] args) {

  }

}
