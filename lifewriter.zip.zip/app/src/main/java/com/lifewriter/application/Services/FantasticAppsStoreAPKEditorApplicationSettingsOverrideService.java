 package com.lifewriter.application.Services;

//public abstract  FantasticAppsStoreAPKEditorApplicationSettingsOverrideService {

 // public static@ main(String() args));



//activate service, show statuses