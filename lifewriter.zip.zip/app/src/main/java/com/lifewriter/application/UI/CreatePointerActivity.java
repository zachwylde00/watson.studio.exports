package com.lifewriter.application.UI;

public abstract class CreatePointerActivity {

  public static void main(String[] args) {

  }

}
