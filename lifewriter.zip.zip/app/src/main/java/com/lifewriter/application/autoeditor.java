package com.lifewriter.application;

public class autoeditor {

  public static void main(String[] args) {

  }

}
