package com.lifewriter.application;

final class privatekeystorageservice {

  public static void main(String[] args) {

  }

}
