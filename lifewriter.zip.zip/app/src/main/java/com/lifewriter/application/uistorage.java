package com.lifewriter.application;

public final class uistorage {

  public static void main(String[] args) {

  }

}
