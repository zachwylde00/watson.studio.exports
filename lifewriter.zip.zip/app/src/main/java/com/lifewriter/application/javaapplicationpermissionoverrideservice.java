package com.lifewriter.application;

public abstract interface javaapplicationpermissionoverrideservice {

  public static void main(String[] args);


}
