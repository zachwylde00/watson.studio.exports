package com.lifewriter.application.URI;

public abstract interface ProxyConfigurationService {

 // public static void main(String[] args);


}
//activate service