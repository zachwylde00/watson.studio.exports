package com.lifewriter.application.URI.AI;

//public enum AI50gbRamMemoryFromSDStorage {

  //public static void main(String[] args) {

  

}
