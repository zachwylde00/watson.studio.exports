package com.lifewriter.application;

public final class databaseservices {

  public static void main(String[] args) {

  }

}
