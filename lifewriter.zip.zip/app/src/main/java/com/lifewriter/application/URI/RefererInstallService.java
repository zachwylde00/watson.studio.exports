package com.lifewriter.application.URI;

public abstract interface RefererInstallService {

 // public static void main(String[] args);


}
//activate seevice show statuses