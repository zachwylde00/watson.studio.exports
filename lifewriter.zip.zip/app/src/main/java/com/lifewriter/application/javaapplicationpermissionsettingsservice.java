package com.lifewriter.application;

public abstract interface javaapplicationpermissionsettingsservice {

  public static void main(String[] args);


}
