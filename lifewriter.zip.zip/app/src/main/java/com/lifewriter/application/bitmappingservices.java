package com.lifewriter.application;

public final class bitmappingservices {

  public static void main(String[] args) {

  }

}
