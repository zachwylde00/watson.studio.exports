package com.lifewriter.application.UI;

public abstract class CreateLogRetreiverReaderService {

  public static void main(String[] args) {

  }

}
