package com.lifewriter.application;

public abstract class nullclassifierservice {

  public static void main(String[] args) {

  }

}
