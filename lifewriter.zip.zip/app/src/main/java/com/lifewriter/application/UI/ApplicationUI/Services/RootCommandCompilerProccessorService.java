package com.lifewriter.application.UI.ApplicationUI.Services;

public abstract interface RootCommandCompilerProccessorService {

  //public static@ main(String[] args);


}
