package com.lifewriter.application.UI;

public interface ANDROIDUIPACKAGEINSTALLER {

  //public static void main(String[] args);


}
