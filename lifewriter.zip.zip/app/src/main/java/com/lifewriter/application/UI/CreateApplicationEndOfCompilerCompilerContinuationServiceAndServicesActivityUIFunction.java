Createpackage com.lifewriter.application.UI;

public abstract class CreateApplicationEndOfCompilerCompilerContinuationServiceAndServicesActivityUIFunction {

  public static void main(String[] args) {

  }

}
