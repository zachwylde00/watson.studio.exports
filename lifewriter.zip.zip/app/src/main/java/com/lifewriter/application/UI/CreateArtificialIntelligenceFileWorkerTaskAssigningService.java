package com.lifewriter.application.UI;

public abstract class CreateArtificialIntelligenceFileWorkerTaskAssigningService {

  public static void main(String[] args) {

  }

}
