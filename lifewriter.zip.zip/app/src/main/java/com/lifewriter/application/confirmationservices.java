package com.lifewriter.application;

abstract class confirmationservices {

  public static void main(String[] args) {

  }

}
