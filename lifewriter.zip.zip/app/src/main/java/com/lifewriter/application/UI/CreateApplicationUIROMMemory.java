package com.lifewriter.application.UI;

public class CreateApplicationUIROMMemory {

  public static void main(String[] args) {

  }

}
