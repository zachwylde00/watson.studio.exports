package com.lifewriter.application.URI;

public abstract interface RadioandListenerService {

 // public static void main(String[] args);


}
//activate service